import pandas as pd
data=pd.read_csv('Final_Results.csv',encoding='ISO-8859-1')
import datetime
for i in range(0,len(data)):
    data.loc[:,'Date'][i]=datetime.datetime.strptime(data.loc[:,'Date'][i],('%Y-%m-%d %H:%M:%S'))

start=min(data.loc[:,'Date'])
months=start.month
days=[]
for i in range(0,len(data)):
    days.append((data.loc[:,'Date'][i]-start).days)

x=[0]*7    
for i in days:
    x[i%7]+=1
y=[1,2,3,4,5,6,7]

import matplotlib.pyplot as plt
plt.plot(y,x)
plt.savefig('Tweets_DayWise.png')
plt.show()

x=[0]*12
for i in days:
    try:
        x[int(i/30)]+=1
    except:
        x[int(i/30)-1]+=1

y=[]
for i in range(0,12):
    if(months+1>12):
        y.append((months)%12)
    else:
        y.append(months)
    months+=1        

plt.scatter(y,x)
plt.savefig('Tweets_Monthwise.png')
plt.show()
